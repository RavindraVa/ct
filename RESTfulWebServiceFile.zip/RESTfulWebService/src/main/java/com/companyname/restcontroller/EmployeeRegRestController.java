package com.companyname.restcontroller;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.companyname.model.Employee1;


@Path("/employee")
public class EmployeeRegRestController {

	@POST
	@Path("/add")
	public Response addEmployee(@FormParam("eid")int empId,@FormParam("ename")String empName,@FormParam("esalary")double salary,@FormParam("eage")int age){
		
		System.out.println(empId+"\t"+empName+"\t"+salary+"\t"+age);
		
		String result=empId+"\t"+empName+"\t"+salary+"\t"+age;
		return Response.status(200).entity(result).build();
	}
	
	@GET
	@Path("/show")
	@Produces("application/xml")
	//@Produces(MediaType.APPLICATION_ATOM_XML)
	public Response showEmployee(){
		
		Employee1 empObj=new Employee1();
		empObj.setEmpId(3031);
		empObj.setEmpName("Gavin King");
		empObj.setSalary(70000.00);
		empObj.setAge(28);
		
		return Response.status(200).entity(empObj).build();
	}
	
}
